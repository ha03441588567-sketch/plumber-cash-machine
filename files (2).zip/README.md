# 🔥 PlumberCash AI — Deployment Guide

## ⚡ GitHub Pages Live karna (15 minutes)

### Step 1: GitHub repo banao
```bash
1. github.com → New Repository
2. Name: plumber-cash-machine
3. Public ✓
4. Create Repository
```

### Step 2: File upload karo
```bash
1. "uploading an existing file" click karo
2. index.html drag & drop karo
3. Commit changes
```

### Step 3: Pages enable karo
```bash
Settings → Pages → Source: main branch → Save
```

### ✅ Live URL:
```
https://[your-username].github.io/plumber-cash-machine
```

---

## 📞 LIVE CALL Integration — VAPI.ai (BEST for plumber)

### Why VAPI?
- Free trial: 10 minutes
- Real phone number milta hai
- AI voice call handle karta hai
- $0.05/minute cost

### Setup Steps:

**1. Account banao:**
```
vapi.ai → Sign Up (free)
```

**2. Phone Number lo:**
```
Dashboard → Phone Numbers → Buy Number
Choose: +61 (Australia) or +971 (UAE)
Monthly cost: ~$2
```

**3. Assistant banao:**
```
Assistants → Create Assistant
Name: "PlumberCash AI"
Voice: "Elliot" ya "Sarah" (natural voice)
```

**4. System Prompt copy karo:**
```
You are an AI receptionist for a professional plumbing business.

When someone calls:
1. Greet: "Hi! You've reached [Business Name]. I'm the AI assistant. How can I help?"
2. Ask: "What's the plumbing issue you're facing today?"
3. Classify: Emergency (burst pipe/flood) → say "This is urgent! I'm alerting our team NOW. Can I get your address?"
4. Normal → "I'll book you in. What's your name and address?"
5. Confirm: "Perfect! I'll send you a confirmation on WhatsApp. Expect a plumber [time]."

Always:
- Sound confident and professional
- Collect: name, address, issue type, best callback number
- End with: "You're all set! We'll send you updates on WhatsApp."
```

**5. Webhook add karo (to get call data):**
```
Server URL: https://your-backend.railway.app/webhook
Or use: n8n.io (free automation) for WhatsApp forwarding
```

**6. index.html mein phone number update karo:**
```html
<!-- Line ~295 mein -->
<a href="tel:+YOUR_VAPI_NUMBER" class="phone-display">+YOUR NUMBER</a>
```

---

## 📱 WhatsApp Automation (FREE with Twilio trial)

### Twilio Free Trial Setup:
```
1. twilio.com → Free account ($15 credit)
2. WhatsApp Sandbox activate karo
3. Webhook URL set karo
4. Test karo
```

### n8n Free Automation Flow:
```
Trigger: VAPI call ends
→ Extract: name, phone, issue
→ Send WhatsApp: "Hi [Name]! We got your call about [issue]. 
   Our plumber will contact you within [time]. 
   Reply URGENT if emergency."
→ Create: Google Sheets row (job log)
→ Notify: Owner's WhatsApp with job brief
```

---

## 💰 Tech Stack (Monthly Cost)

| Service | Cost | Purpose |
|---------|------|---------|
| GitHub Pages | FREE | Website hosting |
| VAPI.ai | ~$10-30 | AI phone calls |
| Twilio WhatsApp | ~$5-15 | WhatsApp messages |
| n8n (cloud) | FREE tier | Automation |
| **TOTAL** | **~$15-45/mo** | Full system |

**Sell for: $299/mo = $250+ profit per client**

---

## 🚀 Quick Test Checklist

- [ ] Website live on GitHub Pages
- [ ] VAPI number active
- [ ] Test call karo — AI picks up?
- [ ] WhatsApp message aaya?
- [ ] Owner ko notification mili?

---

## 📧 Contact

Built by **Karam AI** | karamabbasi79 (Fiverr)
